function C=Company(n)
if n==1
    C='GOOG';
elseif n==2
    C='AAPL';
elseif n==3
    C='NLS';
elseif n==4
    C='MWE';
elseif n==5
    C='IBM';
elseif n==6
    C='AVP';
elseif n==7
    C='CSTM';
elseif n==8
    C='AMD';
elseif n==9
    C='VVUS';
elseif n==10
    C='MRVL';
elseif n==11
    C='X';
elseif n==12
    C='PBR';
elseif n==13
    C='AUY';
elseif n==14
    C='MNKD';
elseif n==15
    C='HRL';
elseif n==16
    C='WLL';
elseif n==17
    C='AMCX';
elseif n==18
    C='FEYE';
elseif n==19
    C='MCD';
elseif n==20
    C='BOX';
elseif n==21
    C='MBLY';
elseif n==22
    C='ATVI';
elseif n==23
    C='NFLX';
elseif n==24
    C='FCX';
elseif n==25
    C='DNR';
elseif n==26
    C='TE';
elseif n==27
    C='LINE';
elseif n==28
    C='NKTR';
elseif n==29
    C='K';
elseif n==30
    C='V';
elseif n==31
    C='HRB';
elseif n==32
    C='BTG';
elseif n==33
    C='CBL';
elseif n==34
    C='CNX';
elseif n==35
    C='DNKN';
elseif n==36
    C='CTRP';
elseif n==37
    C='SBUX';
elseif n==38
    C='LPI';
elseif n==39
    C='FIS';
elseif n==40
    C='FB';
elseif n==41
    C='KING';
elseif n==42
    C='OAS';
elseif n==43
    C='APA';
elseif n==44
    C='HUM';
elseif n==45
    C='WTR';
elseif n==46
    C='DE';
elseif n==47
    C='JPM';
elseif n==48
    C='NVDA';
elseif n==49
    C='MOS';
elseif n==50
    C='ACGL';

    
    
    
    
else
    C=0;
end

end