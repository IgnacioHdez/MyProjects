function C=Corr(n)
Q=getval(n,'quickval');
C=Q(3)*0.00001;
end