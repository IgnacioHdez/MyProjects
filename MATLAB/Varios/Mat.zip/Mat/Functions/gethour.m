function t=gethour()
c=clock;
t=c(4)+c(5)/60+c(6)/3600;
end