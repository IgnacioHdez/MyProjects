 a=[1,3,0];
 b=[1,2,0];
  
 if min(a==b)==1
     disp(1)
 elseif min(a==b)==0
     disp(0)
 end